<?php

use App\Models\{ Employee, Service, Booking};
use Illuminate\Foundation\Testing\RefreshDatabase;
use Carbon\Carbon;
use Illuminate\Support\Facades\Config;
uses(RefreshDatabase::class);
beforeEach(function () {
    Carbon::setTestNow('2025-09-22 08:00:00');
    Config::set('app.timezone','Australia/Melbourne');
});



?>
