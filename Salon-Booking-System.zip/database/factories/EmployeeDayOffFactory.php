<?php

namespace Database\Factories;

use App\Models\Employee;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\EmployeeDayOff>
 */
class EmployeeDayOffFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'weekday' => 0, //$this->faker->numberBetween(0, 6) returns a random number between 0 (Sunday) to 6 (Saturday) for weekdays
            // 'reason' => $this->faker->optional()->sentence(),
        ];
    }
}
