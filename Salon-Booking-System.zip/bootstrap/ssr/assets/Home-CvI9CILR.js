import { getCurrentInstance, inject, nextTick, createApp, defineComponent, toRaw, unref, createElementBlock, openBlock, normalizeClass, normalizeStyle, createBlock, resolveDynamicComponent, mergeProps, withCtx, createTextVNode, createElementVNode, toDisplayString, resolveComponent, createCommentVNode, Fragment, toHandlers, withModifiers, TransitionGroup, renderSlot, renderList, createVNode, computed, ref, watch, useSSRContext, onMounted } from "vue";
import { ssrRenderAttrs, ssrRenderClass, ssrRenderList, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from "vue/server-renderer";
import { useForm, usePage, Head } from "@inertiajs/vue3";
import VueDatePicker from "@vuepic/vue-datepicker";
import axios from "axios";
import "notiflix/build/notiflix-block-aio.js";
import "notiflix/build/notiflix-loading-aio.js";
import { Icon } from "@iconify/vue";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
var __defProp = Object.defineProperty;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var isFunction = (value) => typeof value === "function";
var isString = (value) => typeof value === "string";
var isNonEmptyString = (value) => isString(value) && value.trim().length > 0;
var isNumber = (value) => typeof value === "number";
var isUndefined = (value) => typeof value === "undefined";
var isObject = (value) => typeof value === "object" && value !== null;
var isJSX = (obj) => hasProp(obj, "tag") && isNonEmptyString(obj.tag);
var isTouchEvent = (event) => window.TouchEvent && event instanceof TouchEvent;
var isToastComponent = (obj) => hasProp(obj, "component") && isToastContent(obj.component);
var isVueComponent = (c) => isFunction(c) || isObject(c);
var isToastContent = (obj) => !isUndefined(obj) && (isString(obj) || isVueComponent(obj) || isToastComponent(obj));
var isDOMRect = (obj) => isObject(obj) && ["height", "width", "right", "left", "top", "bottom"].every((p) => isNumber(obj[p]));
var hasProp = (obj, propKey) => (isObject(obj) || isFunction(obj)) && propKey in obj;
var getId = /* @__PURE__ */ ((i) => () => i++)(0);
function getX(event) {
  return isTouchEvent(event) ? event.targetTouches[0].clientX : event.clientX;
}
function getY(event) {
  return isTouchEvent(event) ? event.targetTouches[0].clientY : event.clientY;
}
var removeElement = (el) => {
  if (!isUndefined(el.remove)) {
    el.remove();
  } else if (el.parentNode) {
    el.parentNode.removeChild(el);
  }
};
var getVueComponentFromObj = (obj) => {
  if (isToastComponent(obj)) {
    return getVueComponentFromObj(obj.component);
  }
  if (isJSX(obj)) {
    return defineComponent({
      render() {
        return obj;
      }
    });
  }
  return typeof obj === "string" ? obj : toRaw(unref(obj));
};
var normalizeToastComponent = (obj) => {
  if (typeof obj === "string") {
    return obj;
  }
  const props = hasProp(obj, "props") && isObject(obj.props) ? obj.props : {};
  const listeners = hasProp(obj, "listeners") && isObject(obj.listeners) ? obj.listeners : {};
  return { component: getVueComponentFromObj(obj), props, listeners };
};
var isBrowser = () => typeof window !== "undefined";
var EventBus = class {
  constructor() {
    this.allHandlers = {};
  }
  getHandlers(eventType) {
    return this.allHandlers[eventType] || [];
  }
  on(eventType, handler) {
    const handlers = this.getHandlers(eventType);
    handlers.push(handler);
    this.allHandlers[eventType] = handlers;
  }
  off(eventType, handler) {
    const handlers = this.getHandlers(eventType);
    handlers.splice(handlers.indexOf(handler) >>> 0, 1);
  }
  emit(eventType, event) {
    const handlers = this.getHandlers(eventType);
    handlers.forEach((handler) => handler(event));
  }
};
var isEventBusInterface = (e) => ["on", "off", "emit"].every((f) => hasProp(e, f) && isFunction(e[f]));
var TYPE;
(function(TYPE2) {
  TYPE2["SUCCESS"] = "success";
  TYPE2["ERROR"] = "error";
  TYPE2["WARNING"] = "warning";
  TYPE2["INFO"] = "info";
  TYPE2["DEFAULT"] = "default";
})(TYPE || (TYPE = {}));
var POSITION;
(function(POSITION2) {
  POSITION2["TOP_LEFT"] = "top-left";
  POSITION2["TOP_CENTER"] = "top-center";
  POSITION2["TOP_RIGHT"] = "top-right";
  POSITION2["BOTTOM_LEFT"] = "bottom-left";
  POSITION2["BOTTOM_CENTER"] = "bottom-center";
  POSITION2["BOTTOM_RIGHT"] = "bottom-right";
})(POSITION || (POSITION = {}));
var EVENTS;
(function(EVENTS2) {
  EVENTS2["ADD"] = "add";
  EVENTS2["DISMISS"] = "dismiss";
  EVENTS2["UPDATE"] = "update";
  EVENTS2["CLEAR"] = "clear";
  EVENTS2["UPDATE_DEFAULTS"] = "update_defaults";
})(EVENTS || (EVENTS = {}));
var VT_NAMESPACE = "Vue-Toastification";
var COMMON = {
  type: {
    type: String,
    default: TYPE.DEFAULT
  },
  classNames: {
    type: [String, Array],
    default: () => []
  },
  trueBoolean: {
    type: Boolean,
    default: true
  }
};
var ICON = {
  type: COMMON.type,
  customIcon: {
    type: [String, Boolean, Object, Function],
    default: true
  }
};
var CLOSE_BUTTON = {
  component: {
    type: [String, Object, Function, Boolean],
    default: "button"
  },
  classNames: COMMON.classNames,
  showOnHover: {
    type: Boolean,
    default: false
  },
  ariaLabel: {
    type: String,
    default: "close"
  }
};
var PROGRESS_BAR = {
  timeout: {
    type: [Number, Boolean],
    default: 5e3
  },
  hideProgressBar: {
    type: Boolean,
    default: false
  },
  isRunning: {
    type: Boolean,
    default: false
  }
};
var TRANSITION = {
  transition: {
    type: [Object, String],
    default: `${VT_NAMESPACE}__bounce`
  }
};
var CORE_TOAST = {
  position: {
    type: String,
    default: POSITION.TOP_RIGHT
  },
  draggable: COMMON.trueBoolean,
  draggablePercent: {
    type: Number,
    default: 0.6
  },
  pauseOnFocusLoss: COMMON.trueBoolean,
  pauseOnHover: COMMON.trueBoolean,
  closeOnClick: COMMON.trueBoolean,
  timeout: PROGRESS_BAR.timeout,
  hideProgressBar: PROGRESS_BAR.hideProgressBar,
  toastClassName: COMMON.classNames,
  bodyClassName: COMMON.classNames,
  icon: ICON.customIcon,
  closeButton: CLOSE_BUTTON.component,
  closeButtonClassName: CLOSE_BUTTON.classNames,
  showCloseButtonOnHover: CLOSE_BUTTON.showOnHover,
  accessibility: {
    type: Object,
    default: () => ({
      toastRole: "alert",
      closeButtonLabel: "close"
    })
  },
  rtl: {
    type: Boolean,
    default: false
  },
  eventBus: {
    type: Object,
    required: false,
    default: () => new EventBus()
  }
};
var TOAST = {
  id: {
    type: [String, Number],
    required: true,
    default: 0
  },
  type: COMMON.type,
  content: {
    type: [String, Object, Function],
    required: true,
    default: ""
  },
  onClick: {
    type: Function,
    default: void 0
  },
  onClose: {
    type: Function,
    default: void 0
  }
};
var CONTAINER = {
  container: {
    type: [
      Object,
      Function
    ],
    default: () => document.body
  },
  newestOnTop: COMMON.trueBoolean,
  maxToasts: {
    type: Number,
    default: 20
  },
  transition: TRANSITION.transition,
  toastDefaults: Object,
  filterBeforeCreate: {
    type: Function,
    default: (toast) => toast
  },
  filterToasts: {
    type: Function,
    default: (toasts) => toasts
  },
  containerClassName: COMMON.classNames,
  onMounted: Function,
  shareAppContext: [Boolean, Object]
};
var propValidators_default = {
  CORE_TOAST,
  TOAST,
  CONTAINER,
  PROGRESS_BAR,
  ICON,
  TRANSITION,
  CLOSE_BUTTON
};
var VtProgressBar_default = defineComponent({
  name: "VtProgressBar",
  props: propValidators_default.PROGRESS_BAR,
  data() {
    return {
      hasClass: true
    };
  },
  computed: {
    style() {
      return {
        animationDuration: `${this.timeout}ms`,
        animationPlayState: this.isRunning ? "running" : "paused",
        opacity: this.hideProgressBar ? 0 : 1
      };
    },
    cpClass() {
      return this.hasClass ? `${VT_NAMESPACE}__progress-bar` : "";
    }
  },
  watch: {
    timeout() {
      this.hasClass = false;
      this.$nextTick(() => this.hasClass = true);
    }
  },
  mounted() {
    this.$el.addEventListener("animationend", this.animationEnded);
  },
  beforeUnmount() {
    this.$el.removeEventListener("animationend", this.animationEnded);
  },
  methods: {
    animationEnded() {
      this.$emit("close-toast");
    }
  }
});
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("div", {
    style: normalizeStyle(_ctx.style),
    class: normalizeClass(_ctx.cpClass)
  }, null, 6);
}
VtProgressBar_default.render = render;
var VtProgressBar_default2 = VtProgressBar_default;
var VtCloseButton_default = defineComponent({
  name: "VtCloseButton",
  props: propValidators_default.CLOSE_BUTTON,
  computed: {
    buttonComponent() {
      if (this.component !== false) {
        return getVueComponentFromObj(this.component);
      }
      return "button";
    },
    classes() {
      const classes = [`${VT_NAMESPACE}__close-button`];
      if (this.showOnHover) {
        classes.push("show-on-hover");
      }
      return classes.concat(this.classNames);
    }
  }
});
var _hoisted_1 = /* @__PURE__ */ createTextVNode(" × ");
function render2(_ctx, _cache) {
  return openBlock(), createBlock(resolveDynamicComponent(_ctx.buttonComponent), mergeProps({
    "aria-label": _ctx.ariaLabel,
    class: _ctx.classes
  }, _ctx.$attrs), {
    default: withCtx(() => [
      _hoisted_1
    ]),
    _: 1
  }, 16, ["aria-label", "class"]);
}
VtCloseButton_default.render = render2;
var VtCloseButton_default2 = VtCloseButton_default;
var VtSuccessIcon_default = {};
var _hoisted_12 = {
  "aria-hidden": "true",
  focusable: "false",
  "data-prefix": "fas",
  "data-icon": "check-circle",
  class: "svg-inline--fa fa-check-circle fa-w-16",
  role: "img",
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 512 512"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode("path", {
  fill: "currentColor",
  d: "M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"
}, null, -1);
var _hoisted_3 = [
  _hoisted_2
];
function render3(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_12, _hoisted_3);
}
VtSuccessIcon_default.render = render3;
var VtSuccessIcon_default2 = VtSuccessIcon_default;
var VtInfoIcon_default = {};
var _hoisted_13 = {
  "aria-hidden": "true",
  focusable: "false",
  "data-prefix": "fas",
  "data-icon": "info-circle",
  class: "svg-inline--fa fa-info-circle fa-w-16",
  role: "img",
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 512 512"
};
var _hoisted_22 = /* @__PURE__ */ createElementVNode("path", {
  fill: "currentColor",
  d: "M256 8C119.043 8 8 119.083 8 256c0 136.997 111.043 248 248 248s248-111.003 248-248C504 119.083 392.957 8 256 8zm0 110c23.196 0 42 18.804 42 42s-18.804 42-42 42-42-18.804-42-42 18.804-42 42-42zm56 254c0 6.627-5.373 12-12 12h-88c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h12v-64h-12c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h64c6.627 0 12 5.373 12 12v100h12c6.627 0 12 5.373 12 12v24z"
}, null, -1);
var _hoisted_32 = [
  _hoisted_22
];
function render4(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_13, _hoisted_32);
}
VtInfoIcon_default.render = render4;
var VtInfoIcon_default2 = VtInfoIcon_default;
var VtWarningIcon_default = {};
var _hoisted_14 = {
  "aria-hidden": "true",
  focusable: "false",
  "data-prefix": "fas",
  "data-icon": "exclamation-circle",
  class: "svg-inline--fa fa-exclamation-circle fa-w-16",
  role: "img",
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 512 512"
};
var _hoisted_23 = /* @__PURE__ */ createElementVNode("path", {
  fill: "currentColor",
  d: "M504 256c0 136.997-111.043 248-248 248S8 392.997 8 256C8 119.083 119.043 8 256 8s248 111.083 248 248zm-248 50c-25.405 0-46 20.595-46 46s20.595 46 46 46 46-20.595 46-46-20.595-46-46-46zm-43.673-165.346l7.418 136c.347 6.364 5.609 11.346 11.982 11.346h48.546c6.373 0 11.635-4.982 11.982-11.346l7.418-136c.375-6.874-5.098-12.654-11.982-12.654h-63.383c-6.884 0-12.356 5.78-11.981 12.654z"
}, null, -1);
var _hoisted_33 = [
  _hoisted_23
];
function render5(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_14, _hoisted_33);
}
VtWarningIcon_default.render = render5;
var VtWarningIcon_default2 = VtWarningIcon_default;
var VtErrorIcon_default = {};
var _hoisted_15 = {
  "aria-hidden": "true",
  focusable: "false",
  "data-prefix": "fas",
  "data-icon": "exclamation-triangle",
  class: "svg-inline--fa fa-exclamation-triangle fa-w-18",
  role: "img",
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 576 512"
};
var _hoisted_24 = /* @__PURE__ */ createElementVNode("path", {
  fill: "currentColor",
  d: "M569.517 440.013C587.975 472.007 564.806 512 527.94 512H48.054c-36.937 0-59.999-40.055-41.577-71.987L246.423 23.985c18.467-32.009 64.72-31.951 83.154 0l239.94 416.028zM288 354c-25.405 0-46 20.595-46 46s20.595 46 46 46 46-20.595 46-46-20.595-46-46-46zm-43.673-165.346l7.418 136c.347 6.364 5.609 11.346 11.982 11.346h48.546c6.373 0 11.635-4.982 11.982-11.346l7.418-136c.375-6.874-5.098-12.654-11.982-12.654h-63.383c-6.884 0-12.356 5.78-11.981 12.654z"
}, null, -1);
var _hoisted_34 = [
  _hoisted_24
];
function render6(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_15, _hoisted_34);
}
VtErrorIcon_default.render = render6;
var VtErrorIcon_default2 = VtErrorIcon_default;
var VtIcon_default = defineComponent({
  name: "VtIcon",
  props: propValidators_default.ICON,
  computed: {
    customIconChildren() {
      return hasProp(this.customIcon, "iconChildren") ? this.trimValue(this.customIcon.iconChildren) : "";
    },
    customIconClass() {
      if (isString(this.customIcon)) {
        return this.trimValue(this.customIcon);
      } else if (hasProp(this.customIcon, "iconClass")) {
        return this.trimValue(this.customIcon.iconClass);
      }
      return "";
    },
    customIconTag() {
      if (hasProp(this.customIcon, "iconTag")) {
        return this.trimValue(this.customIcon.iconTag, "i");
      }
      return "i";
    },
    hasCustomIcon() {
      return this.customIconClass.length > 0;
    },
    component() {
      if (this.hasCustomIcon) {
        return this.customIconTag;
      }
      if (isToastContent(this.customIcon)) {
        return getVueComponentFromObj(this.customIcon);
      }
      return this.iconTypeComponent;
    },
    iconTypeComponent() {
      const types = {
        [TYPE.DEFAULT]: VtInfoIcon_default2,
        [TYPE.INFO]: VtInfoIcon_default2,
        [TYPE.SUCCESS]: VtSuccessIcon_default2,
        [TYPE.ERROR]: VtErrorIcon_default2,
        [TYPE.WARNING]: VtWarningIcon_default2
      };
      return types[this.type];
    },
    iconClasses() {
      const classes = [`${VT_NAMESPACE}__icon`];
      if (this.hasCustomIcon) {
        return classes.concat(this.customIconClass);
      }
      return classes;
    }
  },
  methods: {
    trimValue(value, empty = "") {
      return isNonEmptyString(value) ? value.trim() : empty;
    }
  }
});
function render7(_ctx, _cache) {
  return openBlock(), createBlock(resolveDynamicComponent(_ctx.component), {
    class: normalizeClass(_ctx.iconClasses)
  }, {
    default: withCtx(() => [
      createTextVNode(toDisplayString(_ctx.customIconChildren), 1)
    ]),
    _: 1
  }, 8, ["class"]);
}
VtIcon_default.render = render7;
var VtIcon_default2 = VtIcon_default;
var VtToast_default = defineComponent({
  name: "VtToast",
  components: { ProgressBar: VtProgressBar_default2, CloseButton: VtCloseButton_default2, Icon: VtIcon_default2 },
  inheritAttrs: false,
  props: Object.assign({}, propValidators_default.CORE_TOAST, propValidators_default.TOAST),
  data() {
    const data = {
      isRunning: true,
      disableTransitions: false,
      beingDragged: false,
      dragStart: 0,
      dragPos: { x: 0, y: 0 },
      dragRect: {}
    };
    return data;
  },
  computed: {
    classes() {
      const classes = [
        `${VT_NAMESPACE}__toast`,
        `${VT_NAMESPACE}__toast--${this.type}`,
        `${this.position}`
      ].concat(this.toastClassName);
      if (this.disableTransitions) {
        classes.push("disable-transition");
      }
      if (this.rtl) {
        classes.push(`${VT_NAMESPACE}__toast--rtl`);
      }
      return classes;
    },
    bodyClasses() {
      const classes = [
        `${VT_NAMESPACE}__toast-${isString(this.content) ? "body" : "component-body"}`
      ].concat(this.bodyClassName);
      return classes;
    },
    draggableStyle() {
      if (this.dragStart === this.dragPos.x) {
        return {};
      } else if (this.beingDragged) {
        return {
          transform: `translateX(${this.dragDelta}px)`,
          opacity: 1 - Math.abs(this.dragDelta / this.removalDistance)
        };
      } else {
        return {
          transition: "transform 0.2s, opacity 0.2s",
          transform: "translateX(0)",
          opacity: 1
        };
      }
    },
    dragDelta() {
      return this.beingDragged ? this.dragPos.x - this.dragStart : 0;
    },
    removalDistance() {
      if (isDOMRect(this.dragRect)) {
        return (this.dragRect.right - this.dragRect.left) * this.draggablePercent;
      }
      return 0;
    }
  },
  mounted() {
    if (this.draggable) {
      this.draggableSetup();
    }
    if (this.pauseOnFocusLoss) {
      this.focusSetup();
    }
  },
  beforeUnmount() {
    if (this.draggable) {
      this.draggableCleanup();
    }
    if (this.pauseOnFocusLoss) {
      this.focusCleanup();
    }
  },
  methods: {
    hasProp,
    getVueComponentFromObj,
    closeToast() {
      this.eventBus.emit(EVENTS.DISMISS, this.id);
    },
    clickHandler() {
      if (this.onClick) {
        this.onClick(this.closeToast);
      }
      if (this.closeOnClick) {
        if (!this.beingDragged || this.dragStart === this.dragPos.x) {
          this.closeToast();
        }
      }
    },
    timeoutHandler() {
      this.closeToast();
    },
    hoverPause() {
      if (this.pauseOnHover) {
        this.isRunning = false;
      }
    },
    hoverPlay() {
      if (this.pauseOnHover) {
        this.isRunning = true;
      }
    },
    focusPause() {
      this.isRunning = false;
    },
    focusPlay() {
      this.isRunning = true;
    },
    focusSetup() {
      addEventListener("blur", this.focusPause);
      addEventListener("focus", this.focusPlay);
    },
    focusCleanup() {
      removeEventListener("blur", this.focusPause);
      removeEventListener("focus", this.focusPlay);
    },
    draggableSetup() {
      const element = this.$el;
      element.addEventListener("touchstart", this.onDragStart, {
        passive: true
      });
      element.addEventListener("mousedown", this.onDragStart);
      addEventListener("touchmove", this.onDragMove, { passive: false });
      addEventListener("mousemove", this.onDragMove);
      addEventListener("touchend", this.onDragEnd);
      addEventListener("mouseup", this.onDragEnd);
    },
    draggableCleanup() {
      const element = this.$el;
      element.removeEventListener("touchstart", this.onDragStart);
      element.removeEventListener("mousedown", this.onDragStart);
      removeEventListener("touchmove", this.onDragMove);
      removeEventListener("mousemove", this.onDragMove);
      removeEventListener("touchend", this.onDragEnd);
      removeEventListener("mouseup", this.onDragEnd);
    },
    onDragStart(event) {
      this.beingDragged = true;
      this.dragPos = { x: getX(event), y: getY(event) };
      this.dragStart = getX(event);
      this.dragRect = this.$el.getBoundingClientRect();
    },
    onDragMove(event) {
      if (this.beingDragged) {
        event.preventDefault();
        if (this.isRunning) {
          this.isRunning = false;
        }
        this.dragPos = { x: getX(event), y: getY(event) };
      }
    },
    onDragEnd() {
      if (this.beingDragged) {
        if (Math.abs(this.dragDelta) >= this.removalDistance) {
          this.disableTransitions = true;
          this.$nextTick(() => this.closeToast());
        } else {
          setTimeout(() => {
            this.beingDragged = false;
            if (isDOMRect(this.dragRect) && this.pauseOnHover && this.dragRect.bottom >= this.dragPos.y && this.dragPos.y >= this.dragRect.top && this.dragRect.left <= this.dragPos.x && this.dragPos.x <= this.dragRect.right) {
              this.isRunning = false;
            } else {
              this.isRunning = true;
            }
          });
        }
      }
    }
  }
});
var _hoisted_16 = ["role"];
function render8(_ctx, _cache) {
  const _component_Icon = resolveComponent("Icon");
  const _component_CloseButton = resolveComponent("CloseButton");
  const _component_ProgressBar = resolveComponent("ProgressBar");
  return openBlock(), createElementBlock("div", {
    class: normalizeClass(_ctx.classes),
    style: normalizeStyle(_ctx.draggableStyle),
    onClick: _cache[0] || (_cache[0] = (...args) => _ctx.clickHandler && _ctx.clickHandler(...args)),
    onMouseenter: _cache[1] || (_cache[1] = (...args) => _ctx.hoverPause && _ctx.hoverPause(...args)),
    onMouseleave: _cache[2] || (_cache[2] = (...args) => _ctx.hoverPlay && _ctx.hoverPlay(...args))
  }, [
    _ctx.icon ? (openBlock(), createBlock(_component_Icon, {
      key: 0,
      "custom-icon": _ctx.icon,
      type: _ctx.type
    }, null, 8, ["custom-icon", "type"])) : createCommentVNode("v-if", true),
    createElementVNode("div", {
      role: _ctx.accessibility.toastRole || "alert",
      class: normalizeClass(_ctx.bodyClasses)
    }, [
      typeof _ctx.content === "string" ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
        createTextVNode(toDisplayString(_ctx.content), 1)
      ], 2112)) : (openBlock(), createBlock(resolveDynamicComponent(_ctx.getVueComponentFromObj(_ctx.content)), mergeProps({
        key: 1,
        "toast-id": _ctx.id
      }, _ctx.hasProp(_ctx.content, "props") ? _ctx.content.props : {}, toHandlers(_ctx.hasProp(_ctx.content, "listeners") ? _ctx.content.listeners : {}), { onCloseToast: _ctx.closeToast }), null, 16, ["toast-id", "onCloseToast"]))
    ], 10, _hoisted_16),
    !!_ctx.closeButton ? (openBlock(), createBlock(_component_CloseButton, {
      key: 1,
      component: _ctx.closeButton,
      "class-names": _ctx.closeButtonClassName,
      "show-on-hover": _ctx.showCloseButtonOnHover,
      "aria-label": _ctx.accessibility.closeButtonLabel,
      onClick: withModifiers(_ctx.closeToast, ["stop"])
    }, null, 8, ["component", "class-names", "show-on-hover", "aria-label", "onClick"])) : createCommentVNode("v-if", true),
    _ctx.timeout ? (openBlock(), createBlock(_component_ProgressBar, {
      key: 2,
      "is-running": _ctx.isRunning,
      "hide-progress-bar": _ctx.hideProgressBar,
      timeout: _ctx.timeout,
      onCloseToast: _ctx.timeoutHandler
    }, null, 8, ["is-running", "hide-progress-bar", "timeout", "onCloseToast"])) : createCommentVNode("v-if", true)
  ], 38);
}
VtToast_default.render = render8;
var VtToast_default2 = VtToast_default;
var VtTransition_default = defineComponent({
  name: "VtTransition",
  props: propValidators_default.TRANSITION,
  emits: ["leave"],
  methods: {
    hasProp,
    leave(el) {
      if (el instanceof HTMLElement) {
        el.style.left = el.offsetLeft + "px";
        el.style.top = el.offsetTop + "px";
        el.style.width = getComputedStyle(el).width;
        el.style.position = "absolute";
      }
    }
  }
});
function render9(_ctx, _cache) {
  return openBlock(), createBlock(TransitionGroup, {
    tag: "div",
    "enter-active-class": _ctx.transition.enter ? _ctx.transition.enter : `${_ctx.transition}-enter-active`,
    "move-class": _ctx.transition.move ? _ctx.transition.move : `${_ctx.transition}-move`,
    "leave-active-class": _ctx.transition.leave ? _ctx.transition.leave : `${_ctx.transition}-leave-active`,
    onLeave: _ctx.leave
  }, {
    default: withCtx(() => [
      renderSlot(_ctx.$slots, "default")
    ]),
    _: 3
  }, 8, ["enter-active-class", "move-class", "leave-active-class", "onLeave"]);
}
VtTransition_default.render = render9;
var VtTransition_default2 = VtTransition_default;
var VtToastContainer_default = defineComponent({
  name: "VueToastification",
  devtools: {
    hide: true
  },
  components: { Toast: VtToast_default2, VtTransition: VtTransition_default2 },
  props: Object.assign({}, propValidators_default.CORE_TOAST, propValidators_default.CONTAINER, propValidators_default.TRANSITION),
  data() {
    const data = {
      count: 0,
      positions: Object.values(POSITION),
      toasts: {},
      defaults: {}
    };
    return data;
  },
  computed: {
    toastArray() {
      return Object.values(this.toasts);
    },
    filteredToasts() {
      return this.defaults.filterToasts(this.toastArray);
    }
  },
  beforeMount() {
    const events = this.eventBus;
    events.on(EVENTS.ADD, this.addToast);
    events.on(EVENTS.CLEAR, this.clearToasts);
    events.on(EVENTS.DISMISS, this.dismissToast);
    events.on(EVENTS.UPDATE, this.updateToast);
    events.on(EVENTS.UPDATE_DEFAULTS, this.updateDefaults);
    this.defaults = this.$props;
  },
  mounted() {
    this.setup(this.container);
  },
  methods: {
    async setup(container) {
      if (isFunction(container)) {
        container = await container();
      }
      removeElement(this.$el);
      container.appendChild(this.$el);
    },
    setToast(props) {
      if (!isUndefined(props.id)) {
        this.toasts[props.id] = props;
      }
    },
    addToast(params) {
      params.content = normalizeToastComponent(params.content);
      const props = Object.assign({}, this.defaults, params.type && this.defaults.toastDefaults && this.defaults.toastDefaults[params.type], params);
      const toast = this.defaults.filterBeforeCreate(props, this.toastArray);
      toast && this.setToast(toast);
    },
    dismissToast(id) {
      const toast = this.toasts[id];
      if (!isUndefined(toast) && !isUndefined(toast.onClose)) {
        toast.onClose();
      }
      delete this.toasts[id];
    },
    clearToasts() {
      Object.keys(this.toasts).forEach((id) => {
        this.dismissToast(id);
      });
    },
    getPositionToasts(position) {
      const toasts = this.filteredToasts.filter((toast) => toast.position === position).slice(0, this.defaults.maxToasts);
      return this.defaults.newestOnTop ? toasts.reverse() : toasts;
    },
    updateDefaults(update) {
      if (!isUndefined(update.container)) {
        this.setup(update.container);
      }
      this.defaults = Object.assign({}, this.defaults, update);
    },
    updateToast({
      id,
      options,
      create
    }) {
      if (this.toasts[id]) {
        if (options.timeout && options.timeout === this.toasts[id].timeout) {
          options.timeout++;
        }
        this.setToast(Object.assign({}, this.toasts[id], options));
      } else if (create) {
        this.addToast(Object.assign({}, { id }, options));
      }
    },
    getClasses(position) {
      const classes = [`${VT_NAMESPACE}__container`, position];
      return classes.concat(this.defaults.containerClassName);
    }
  }
});
function render10(_ctx, _cache) {
  const _component_Toast = resolveComponent("Toast");
  const _component_VtTransition = resolveComponent("VtTransition");
  return openBlock(), createElementBlock("div", null, [
    (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.positions, (pos) => {
      return openBlock(), createElementBlock("div", { key: pos }, [
        createVNode(_component_VtTransition, {
          transition: _ctx.defaults.transition,
          class: normalizeClass(_ctx.getClasses(pos))
        }, {
          default: withCtx(() => [
            (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.getPositionToasts(pos), (toast) => {
              return openBlock(), createBlock(_component_Toast, mergeProps({
                key: toast.id
              }, toast), null, 16);
            }), 128))
          ]),
          _: 2
        }, 1032, ["transition", "class"])
      ]);
    }), 128))
  ]);
}
VtToastContainer_default.render = render10;
var VtToastContainer_default2 = VtToastContainer_default;
var buildInterface = (globalOptions = {}, mountContainer = true) => {
  const events = globalOptions.eventBus = globalOptions.eventBus || new EventBus();
  if (mountContainer) {
    nextTick(() => {
      const app = createApp(VtToastContainer_default2, __spreadValues({}, globalOptions));
      const component = app.mount(document.createElement("div"));
      const onMounted2 = globalOptions.onMounted;
      if (!isUndefined(onMounted2)) {
        onMounted2(component, app);
      }
      if (globalOptions.shareAppContext) {
        const baseApp = globalOptions.shareAppContext;
        if (baseApp === true) {
          console.warn(`[${VT_NAMESPACE}] App to share context with was not provided.`);
        } else {
          app._context.components = baseApp._context.components;
          app._context.directives = baseApp._context.directives;
          app._context.mixins = baseApp._context.mixins;
          app._context.provides = baseApp._context.provides;
          app.config.globalProperties = baseApp.config.globalProperties;
        }
      }
    });
  }
  const toast = (content, options) => {
    const props = Object.assign({}, { id: getId(), type: TYPE.DEFAULT }, options, {
      content
    });
    events.emit(EVENTS.ADD, props);
    return props.id;
  };
  toast.clear = () => events.emit(EVENTS.CLEAR, void 0);
  toast.updateDefaults = (update) => {
    events.emit(EVENTS.UPDATE_DEFAULTS, update);
  };
  toast.dismiss = (id) => {
    events.emit(EVENTS.DISMISS, id);
  };
  function updateToast(id, { content, options }, create = false) {
    const opt = Object.assign({}, options, { content });
    events.emit(EVENTS.UPDATE, {
      id,
      options: opt,
      create
    });
  }
  toast.update = updateToast;
  toast.success = (content, options) => toast(content, Object.assign({}, options, { type: TYPE.SUCCESS }));
  toast.info = (content, options) => toast(content, Object.assign({}, options, { type: TYPE.INFO }));
  toast.error = (content, options) => toast(content, Object.assign({}, options, { type: TYPE.ERROR }));
  toast.warning = (content, options) => toast(content, Object.assign({}, options, { type: TYPE.WARNING }));
  return toast;
};
var createMockToastInterface = () => {
  const toast = () => console.warn(`[${VT_NAMESPACE}] This plugin does not support SSR!`);
  return new Proxy(toast, {
    get() {
      return toast;
    }
  });
};
function createToastInterface(optionsOrEventBus) {
  if (!isBrowser()) {
    return createMockToastInterface();
  }
  if (isEventBusInterface(optionsOrEventBus)) {
    return buildInterface({ eventBus: optionsOrEventBus }, false);
  }
  return buildInterface(optionsOrEventBus, true);
}
var toastInjectionKey = Symbol("VueToastification");
var globalEventBus = new EventBus();
var useToast$1 = (eventBus) => {
  const toast = getCurrentInstance() ? inject(toastInjectionKey, void 0) : void 0;
  return toast ? toast : createToastInterface(globalEventBus);
};
const _sfc_main$8 = {
  __name: "Booking",
  __ssrInlineRender: true,
  props: {
    employees: Array,
    services: Array,
    minDate: String,
    maxDate: String
  },
  setup(__props) {
    const props = __props;
    const employeesOfService = computed(() => {
      var _a;
      return ((_a = props.services.find((service) => service.id === BookingForm.step1.service_id)) == null ? void 0 : _a.employees) || [];
    });
    const disabledDates = computed(() => {
      var _a;
      const employee = (_a = props.employees) == null ? void 0 : _a.find((emp) => emp.id == BookingForm.step2.employee_id);
      const rawDaysOff = employee == null ? void 0 : employee.all_days_off_as_date;
      if (!rawDaysOff) return [];
      let cleanDates = [];
      if (Array.isArray(rawDaysOff)) {
        cleanDates = rawDaysOff.filter((date) => date != null && date !== "");
      } else if (typeof rawDaysOff === "object") {
        cleanDates = Object.values(rawDaysOff).filter((date) => date != null && date !== "");
      }
      const validDates = cleanDates.map((date) => new Date(date)).filter((date) => !isNaN(date.getTime()));
      return validDates;
    });
    const disabledDays = computed(() => {
      var _a;
      return BookingForm.step2.employee_id ? ((_a = props.employees.find((emp) => emp.id == BookingForm.step2.employee_id)) == null ? void 0 : _a.weekly_days_off) || [] : [];
    });
    const bookingSummary = computed(() => {
      const service = props.services.find((svc) => svc.id === BookingForm.step1.service_id);
      const employee = props.employees.find((emp) => emp.id === BookingForm.step2.employee_id);
      return {
        serviceName: service ? service.name : "",
        servicePrice: service ? service.price : 0,
        serviceDuration: service ? service.duration_minutes : 0,
        employeeName: employee ? employee.name : "",
        date: BookingForm.step3.date,
        time: BookingForm.step3.datetime
      };
    });
    const availableTimes = ref([]);
    const step = ref(1);
    ref(false);
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const enableTimeTable = computed(() => {
      return availableTimes.value.length < 0;
    });
    const BookingForm = useForm({
      step1: {
        service_id: ""
      },
      step2: {
        employee_id: ""
      },
      step3: {
        date: "",
        datetime: ""
      },
      step4: {
        customer_name: "",
        customer_email: "",
        customer_phone: ""
      }
    });
    function resetForm() {
      BookingForm.step1.service_id = "";
      BookingForm.step2.employee_id = "";
      BookingForm.step3.date = "";
      BookingForm.step3.datetime = "";
      BookingForm.step4.customer_name = "";
      BookingForm.step4.customer_email = "";
      BookingForm.step4.customer_phone = "";
      step.value = 1;
    }
    const handleDate = async (modelData) => {
      BookingForm.step3.date = modelData;
      try {
        const response = await axios.get(route("check-availability"), {
          params: {
            employee_id: BookingForm.step2.employee_id,
            service_id: BookingForm.step1.service_id,
            date: BookingForm.step3.date
          }
        });
        availableTimes.value = response.data.available_slots || [];
        console.log("Available times:", availableTimes.value);
        if (availableTimes.value.length === 0) {
          useToast$1().info("No available time slots for the selected date. Please choose another date.");
        }
      } catch (error) {
        console.error("Error fetching available times:", error);
        availableTimes.value = [];
        useToast$1().error("Error fetching available times.");
      }
    };
    watch(BookingForm, (newVal) => {
      console.log(newVal.step1.service_id, newVal.step2.employee_id, newVal.step3.date, newVal.step3.datetime, newVal.step4.customer_name, newVal.step4.customer_email, newVal.step4.customer_phone);
      console.log(step.value);
    }, { deep: true });
    watch(step, (newStep) => {
      if (newStep === 1) {
        resetForm();
      }
    });
    console.log(usePage().props);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({
        id: "booking",
        class: "py-32 bg-gradient-to-br from-gray-900 via-gray-850 to-gray-900"
      }, _attrs))} data-v-453cef07><div class="max-w-5xl mx-auto px-4" data-v-453cef07><div class="text-center mb-16" data-v-453cef07><h2 class="text-4xl lg:text-6xl font-bold text-gray-100 mb-6" data-v-453cef07>Book Your Appointment</h2><p class="text-xl text-gray-400" data-v-453cef07>Quick and easy 4-step booking process</p><p class="text-lg text-gray-300 mt-4 mb-8" data-v-453cef07>Any Issue while booking? <a href="#" class="text-primary-500" data-v-453cef07>Contact Support Or Call Us Now: 1700 100 100</a></p></div><div class="flex items-center justify-center gap-4 mb-16 flex-wrap" data-v-453cef07><div class="flex items-center gap-3" data-v-453cef07><div class="${ssrRenderClass([{ "bg-gradient-to-r from-primary-600 to-primary-500 text-white shadow-xl": step.value >= 1 }, "w-12 h-12 rounded-full flex items-center justify-center font-semibold"])}" data-v-453cef07>1</div><span class="text-gray-300 font-medium" data-v-453cef07>Service</span></div><div class="h-px w-12 bg-gray-600 hidden sm:block" data-v-453cef07></div><div class="flex items-center gap-3" data-v-453cef07><div class="${ssrRenderClass([{ "bg-gradient-to-r from-primary-600 to-primary-500 text-white shadow-xl": step.value >= 2 }, "w-12 h-12 rounded-full flex items-center justify-center border-2 border-gray-600 font-semibold"])}" data-v-453cef07>2</div><span class="text-gray-300 font-medium" data-v-453cef07>Barber</span></div><div class="h-px w-12 bg-gray-600 hidden sm:block" data-v-453cef07></div><div class="flex items-center gap-3" data-v-453cef07><div class="${ssrRenderClass([{ "bg-gradient-to-r from-primary-600 to-primary-500 text-white shadow-xl": step.value >= 3 }, "w-12 h-12 rounded-full flex items-center justify-center border-2 border-gray-600 font-semibold"])}" data-v-453cef07>3</div><span class="text-gray-300 font-medium" data-v-453cef07>Date &amp; Time</span></div><div class="h-px w-12 bg-gray-600 hidden sm:block" data-v-453cef07></div><div class="flex items-center gap-3" data-v-453cef07><div class="${ssrRenderClass([{ "bg-gradient-to-r from-primary-600 to-primary-500 text-white shadow-xl": step.value >= 4 }, "w-12 h-12 rounded-full flex items-center justify-center border-2 border-gray-600 font-semibold"])}" data-v-453cef07>4</div><span class="text-gray-300 font-medium" data-v-453cef07>Confirm</span></div></div><form class="space-y-10" data-v-453cef07>`);
      if (step.value === 1) {
        _push(`<div data-v-453cef07><h3 class="text-2xl font-semibold mb-8 text-gray-100" data-v-453cef07>Choose Your Service</h3><div class="grid sm:grid-cols-2 gap-6" data-v-453cef07><!--[-->`);
        ssrRenderList(__props.services, (service) => {
          _push(`<button type="button" class="p-6 rounded-xl bg-gray-800/50 border border-gray-700 text-left hover:bg-gray-800 hover:border-primary-500/50 transition-all focus:ring-2 focus:ring-primary-500" data-v-453cef07><div class="flex items-start gap-4" data-v-453cef07><div class="text-3xl" data-v-453cef07>`);
          _push(ssrRenderComponent(unref(Icon), {
            icon: service.icon,
            width: "35",
            height: "35"
          }, null, _parent));
          _push(`</div><div class="flex-1" data-v-453cef07><div class="font-semibold text-lg mb-2 text-gray-100" data-v-453cef07>${ssrInterpolate(service.name)}</div><div class="text-sm text-gray-400 mb-3 leading-relaxed" data-v-453cef07>${ssrInterpolate(service.description)}</div><div class="flex justify-between items-center" data-v-453cef07><span class="text-sm text-gray-500" data-v-453cef07>Duration: ${ssrInterpolate(service.duration_minutes)} min</span><span class="font-bold text-2xl text-primary-400" data-v-453cef07>$${ssrInterpolate(service.price)}</span></div></div></div></button>`);
        });
        _push(`<!--]--></div></div>`);
      } else if (step.value === 2) {
        _push(`<div data-v-453cef07><h3 class="text-2xl font-semibold mb-8 text-gray-100" data-v-453cef07>Select Your Barber</h3><div class="grid sm:grid-cols-2 gap-6" data-v-453cef07><!--[-->`);
        ssrRenderList(employeesOfService.value, (employee) => {
          _push(`<button type="button" class="${ssrRenderClass([{ "ring-2 ring-primary-500": unref(BookingForm).step2.employee_id === employee.id }, "p-6 rounded-xl bg-gray-800/50 border border-gray-700 text-left hover:bg-gray-800 hover:border-primary-500/50 transition-all focus:ring-2 focus:ring-primary-500"])}" data-v-453cef07><div class="flex items-center gap-4" data-v-453cef07><img${ssrRenderAttr("src", employee.photo)} class="w-16 h-16 rounded-full object-cover border-2 border-gray-600"${ssrRenderAttr("alt", employee.name)} data-v-453cef07><div class="flex-1" data-v-453cef07><div class="font-semibold text-lg text-gray-100" data-v-453cef07>${ssrInterpolate(employee.name)}</div><div class="text-sm text-gray-300" data-v-453cef07>${ssrInterpolate(employee.job_title)}</div><div class="text-sm text-primary-400" data-v-453cef07>⭐ ${ssrInterpolate(employee.rating)}/5 • Hours: ${ssrInterpolate(employee.work_start_time)}–${ssrInterpolate(employee.work_end_time)}</div></div></div></button>`);
        });
        _push(`<!--]--></div><p class="text-sm text-gray-400 mt-6" data-v-453cef07>Only barbers qualified for your selected service are shown. (Static preview)</p></div>`);
      } else if (step.value === 3) {
        _push(`<div data-v-453cef07><h3 class="text-2xl font-semibold mb-8 text-gray-100" data-v-453cef07>Pick Date &amp; Time</h3><div class="grid sm:grid-cols-2 gap-0 space-y-6 sm:space-y-0 sm:gap-6" data-v-453cef07><div data-v-453cef07><label class="block mb-4 font-medium text-gray-300" data-v-453cef07>Date</label>`);
        _push(ssrRenderComponent(unref(VueDatePicker), {
          "min-date": __props.minDate,
          "max-date": __props.maxDate,
          "model-value": unref(BookingForm).step3.date,
          "onUpdate:modelValue": handleDate,
          "disabled-week-days": disabledDays.value,
          "disabled-dates": disabledDates.value,
          "enable-time-picker": false,
          dark: true,
          timezone: unref(tz),
          "auto-apply": "",
          inline: "",
          class: "dp-wide",
          "input-class": "w-full px-4 py-4 rounded-xl bg-gray-800 text-gray-100 border border-gray-700 focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
        }, null, _parent));
        _push(`</div><div data-v-453cef07><label class="block mb-4 font-medium text-gray-300" data-v-453cef07>Time</label><select${ssrIncludeBooleanAttr(enableTimeTable.value) ? " disabled" : ""} size="12" class="w-full px-4 py-4 rounded-sm bg-gray-800 text-gray-100 border border-gray-700 focus:ring-2 focus:ring-primary-500 focus:border-primary-500" data-v-453cef07><option disabled data-v-453cef07${ssrIncludeBooleanAttr(Array.isArray(unref(BookingForm).step3.datetime) ? ssrLooseContain(unref(BookingForm).step3.datetime, null) : ssrLooseEqual(unref(BookingForm).step3.datetime, null)) ? " selected" : ""}>Select time</option><!--[-->`);
        ssrRenderList(availableTimes.value, (time) => {
          _push(`<option${ssrRenderAttr("value", time)} data-v-453cef07${ssrIncludeBooleanAttr(Array.isArray(unref(BookingForm).step3.datetime) ? ssrLooseContain(unref(BookingForm).step3.datetime, time) : ssrLooseEqual(unref(BookingForm).step3.datetime, time)) ? " selected" : ""}>${ssrInterpolate(time)}</option>`);
        });
        _push(`<!--]--></select></div></div><p class="text-sm text-gray-400 mt-6" data-v-453cef07>Available times depend on your selected barber&#39;s schedule. (Static preview)</p></div>`);
      } else if (step.value === 4) {
        _push(`<div data-v-453cef07><h3 class="text-2xl font-semibold mb-8 text-gray-100" data-v-453cef07>Review &amp; Confirm</h3><div class="bg-gray-800/50 border border-gray-700 rounded-xl p-8 mb-8 backdrop-blur" data-v-453cef07><div class="space-y-4" data-v-453cef07><div class="flex justify-between items-center py-3 border-b border-gray-700" data-v-453cef07><span class="text-gray-400" data-v-453cef07>Service:</span><span class="font-semibold text-gray-100" data-v-453cef07>${ssrInterpolate(bookingSummary.value.serviceName)}</span></div><div class="flex justify-between items-center py-3 border-b border-gray-700" data-v-453cef07><span class="text-gray-400" data-v-453cef07>Price:</span><span class="font-semibold text-2xl text-primary-400" data-v-453cef07>${ssrInterpolate(bookingSummary.value.servicePrice)} AUD</span></div><div class="flex justify-between items-center py-3 border-b border-gray-700" data-v-453cef07><span class="text-gray-400" data-v-453cef07>Duration:</span><span class="font-semibold text-gray-100" data-v-453cef07>${ssrInterpolate(bookingSummary.value.serviceDuration)} minutes</span></div><div class="flex justify-between items-center py-3 border-b border-gray-700" data-v-453cef07><span class="text-gray-400" data-v-453cef07>Barber:</span><span class="font-semibold text-gray-100" data-v-453cef07>${ssrInterpolate(bookingSummary.value.employeeName)}</span></div><div class="flex justify-between items-center py-3 border-b border-gray-700" data-v-453cef07><span class="text-gray-400" data-v-453cef07>Date:</span><span class="font-semibold text-gray-100" data-v-453cef07>${ssrInterpolate(new Intl.DateTimeFormat("en", { day: "2-digit", month: "long", year: "numeric", timeZone: unref(tz) }).format(bookingSummary.value.date))}</span></div><div class="flex justify-between items-center py-3" data-v-453cef07><span class="text-gray-400" data-v-453cef07>Time:</span><span class="font-semibold text-primary-400 text-xl" data-v-453cef07>${ssrInterpolate(bookingSummary.value.time.trim().split(" ")[1])}</span></div></div></div><div class="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8" data-v-453cef07><input${ssrRenderAttr("value", unref(BookingForm).step4.customer_name)} class="px-4 py-4 rounded-xl bg-gray-800 text-gray-100 border border-gray-700 focus:ring-2 focus:ring-primary-500 focus:border-primary-500" placeholder="Full Name" data-v-453cef07><input${ssrRenderAttr("value", unref(BookingForm).step4.customer_email)} class="px-4 py-4 rounded-xl bg-gray-800 text-gray-100 border border-gray-700 focus:ring-2 focus:ring-primary-500 focus:border-primary-500" placeholder="Email Address" data-v-453cef07><input${ssrRenderAttr("value", unref(BookingForm).step4.customer_phone)} class="px-4 py-4 rounded-xl bg-gray-800 text-gray-100 border border-gray-700 focus:ring-2 focus:ring-primary-500 focus:border-primary-500" placeholder="Phone Number" data-v-453cef07></div><button type="submit" class="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-primary-600 to-primary-500 text-white font-semibold hover:shadow-xl hover:shadow-primary-500/25 transition-all" data-v-453cef07> Confirm Booking </button></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="flex gap-4 pt-8 border-t border-gray-700" data-v-453cef07>`);
      if (step.value > 1) {
        _push(`<button id="prevBtn" type="button" class="px-6 py-3 rounded-xl border border-gray-600 text-gray-300 hover:bg-gray-800 transition-all disabled:opacity-40 disabled:cursor-not-allowed" data-v-453cef07> Previous </button>`);
      } else {
        _push(`<!---->`);
      }
      if (step.value < 4) {
        _push(`<button id="nextBtn" type="button" class="px-6 py-3 rounded-xl bg-gradient-to-r from-primary-600 to-primary-500 text-white font-semibold hover:shadow-xl hover:shadow-primary-500/25 transition-all" data-v-453cef07> Next </button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></form></div></section>`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Home/Booking.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const Booking = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["__scopeId", "data-v-453cef07"]]);
const _sfc_main$7 = {};
function _sfc_ssrRender$3(_ctx, _push, _parent, _attrs) {
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "py-32 bg-gray-900/50" }, _attrs))}><div class="max-w-7xl mx-auto px-4"><div class="text-center mb-20"><h2 class="text-4xl lg:text-6xl font-bold text-gray-100 mb-6">Why Choose Us?</h2><p class="text-xl text-gray-400 max-w-3xl mx-auto leading-relaxed"> Professional service, transparent pricing, and a booking experience designed for your convenience. </p></div><div class="grid lg:grid-cols-3 gap-10"><div class="relative group h-full"><div class="absolute inset-0 bg-gradient-to-r from-primary-600 to-primary-500 rounded-2xl opacity-0 group-hover:opacity-100 transition-all duration-500 blur-xl"></div><div class="relative h-full p-10 bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl border border-gray-700 hover:border-primary-500/50 transition-all duration-500"><div class="w-16 h-16 bg-gray-700 rounded-2xl flex items-center justify-center text-gray-300 text-2xl mb-8 group-hover:bg-primary-500/20 group-hover:text-primary-400 transition-all duration-300"><svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"></path></svg></div><h3 class="font-bold text-2xl text-gray-100 mb-4">Master Barbers</h3><p class="text-gray-400 text-lg leading-relaxed">Skilled professionals with years of experience in modern fades, classic cuts, and precision styling with personal consultation.</p></div></div><div class="relative group h-full"><div class="absolute inset-0 bg-gradient-to-r from-primary-600 to-primary-500 rounded-2xl opacity-0 group-hover:opacity-100 transition-all duration-500 blur-xl"></div><div class="relative h-full p-10 bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl border border-gray-700 hover:border-primary-500/50 transition-all duration-500"><div class="w-16 h-16 bg-gray-700 rounded-2xl flex items-center justify-center text-gray-300 text-2xl mb-8 group-hover:bg-primary-500/20 group-hover:text-primary-400 transition-all duration-300"><svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"></path></svg></div><h3 class="font-bold text-2xl text-gray-100 mb-4">Transparent Pricing</h3><p class="text-gray-400 text-lg leading-relaxed">Clear, upfront pricing with no hidden fees. Premium service packages and loyalty rewards for regular clients.</p></div></div><div class="relative group h-full"><div class="absolute inset-0 bg-gradient-to-r from-primary-600 to-primary-500 rounded-2xl opacity-0 group-hover:opacity-100 transition-all duration-500 blur-xl"></div><div class="relative h-full p-10 bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl border border-gray-700 hover:border-primary-500/50 transition-all duration-500"><div class="w-16 h-16 bg-gray-700 rounded-2xl flex items-center justify-center text-gray-300 text-2xl mb-8 group-hover:bg-primary-500/20 group-hover:text-primary-400 transition-all duration-300"><svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M17 12h-5v5h5v-5zM16 1v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2h-1V1h-2zm3 18H5V8h14v11z"></path></svg></div><h3 class="font-bold text-2xl text-gray-100 mb-4">Smart Booking</h3><p class="text-gray-400 text-lg leading-relaxed">Streamlined 4-step process: Choose service → Select barber → Pick time → Instant confirmation. Simple and efficient.</p></div></div></div></div></section>`);
}
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Home/Feature.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const Feature = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["ssrRender", _sfc_ssrRender$3]]);
const _sfc_main$6 = {};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs) {
  _push(`<footer${ssrRenderAttrs(mergeProps({ class: "bg-gray-950 border-t border-gray-800" }, _attrs))}><div class="max-w-7xl mx-auto px-4 py-16"><div class="grid lg:grid-cols-4 gap-10"><div class="lg:col-span-2"><div class="flex items-center gap-3 font-bold text-xl mb-6"><div class="w-10 h-10 bg-gradient-to-br from-primary-600 to-primary-700 rounded-lg flex items-center justify-center text-lg">✂️</div><span class="text-gray-100">Skin Fade Barbershop</span></div><p class="text-gray-400 leading-relaxed mb-6 max-w-md">Premium men&#39;s grooming services in the heart of the city. Professional cuts, expert styling, and exceptional service since 2020.</p><div class="text-gray-300 space-y-2"><p class="flex items-center gap-2">📍 Downtown • 4th Circle</p><p class="flex items-center gap-2">🕐 Daily 10 AM - 9 PM</p></div></div><div><div class="font-semibold text-lg mb-6 text-gray-100">Contact</div><div class="space-y-3 text-gray-300"><p class="flex items-center gap-2">📱 +962 7X XXX XXXX</p><p class="flex items-center gap-2">📧 info@skinfadebarbershop.com</p><p class="flex items-center gap-2">📸 @skin.fade.barber</p></div></div><div><div class="font-semibold text-lg mb-6 text-gray-100">Quick Links</div><ul class="space-y-3"><li><a href="#services" class="text-gray-300 hover:text-primary-400 transition-colors">Services</a></li><li><a href="#team" class="text-gray-300 hover:text-primary-400 transition-colors">Our Team</a></li><li><a href="#testimonials" class="text-gray-300 hover:text-primary-400 transition-colors">Reviews</a></li><li><a href="#booking" class="text-gray-300 hover:text-primary-400 transition-colors">Book Now</a></li></ul></div></div><div class="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400"><p>© 2024 Skin Fade Barbershop. All rights reserved.</p></div></div></footer>`);
}
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Home/Footer.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const Footer = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["ssrRender", _sfc_ssrRender$2]]);
const _sfc_main$5 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "relative overflow-hidden pt-20 min-h-screen flex items-center" }, _attrs))}><div class="absolute inset-0 bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950"></div><div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary-900/20 via-transparent to-transparent"></div><div class="relative max-w-7xl mx-auto px-4 py-32 grid lg:grid-cols-2 gap-16 items-center"><div><div class="inline-flex items-center gap-2 bg-primary-500/10 border border-primary-500/20 rounded-full px-4 py-2 text-sm text-primary-300 mb-8"><div class="w-2 h-2 bg-primary-500 rounded-full"></div> Now Open - Book Your Appointment </div><h1 class="text-5xl lg:text-7xl font-black leading-tight text-gray-100"> Sharp Cuts. <br><span class="bg-gradient-to-r from-primary-400 to-primary-600 bg-clip-text text-transparent">Premium Style.</span><br><span class="text-3xl lg:text-5xl font-semibold text-gray-400">Book in Seconds.</span></h1><p class="mt-8 text-xl text-gray-300 leading-relaxed max-w-lg"> Experience the finest men&#39;s grooming with precision cuts, expert beard styling, and luxury treatments. Our smart booking system makes scheduling effortless. </p><div class="mt-12 flex flex-col sm:flex-row gap-4"><a href="#booking" class="group px-8 py-4 bg-gradient-to-r from-primary-600 to-primary-500 text-white rounded-xl font-semibold hover:shadow-2xl hover:shadow-primary-500/25 transition-all text-center"><span class="group-hover:translate-x-1 transition-transform inline-block">Start Booking →</span></a><a href="#services" class="px-8 py-4 border-2 border-gray-700 text-gray-300 rounded-xl font-semibold hover:bg-gray-800 hover:border-primary-500/50 transition-all text-center">View Services</a></div><div class="mt-16 grid grid-cols-2 lg:grid-cols-4 gap-4"><div class="p-4 bg-gray-900/50 border border-gray-800 rounded-xl text-center backdrop-blur"><div class="text-2xl mb-2">✂️</div><div class="text-sm font-medium text-gray-200">Sterilized Tools</div></div><div class="p-4 bg-gray-900/50 border border-gray-800 rounded-xl text-center backdrop-blur"><div class="text-2xl mb-2">⏰</div><div class="text-sm font-medium text-gray-200">On-Time Service</div></div><div class="p-4 bg-gray-900/50 border border-gray-800 rounded-xl text-center backdrop-blur"><div class="text-2xl mb-2">⭐</div><div class="text-sm font-medium text-gray-200">4.9/5 Rating</div></div><div class="p-4 bg-gray-900/50 border border-gray-800 rounded-xl text-center backdrop-blur"><div class="text-2xl mb-2">🏆</div><div class="text-sm font-medium text-gray-200">Award Winning</div></div></div></div><div class="relative"><div class="absolute inset-0 bg-gradient-to-tr from-primary-600/30 to-transparent rounded-3xl transform rotate-3"></div><div class="absolute -inset-4 bg-gradient-to-r from-primary-600/20 to-primary-400/20 rounded-3xl blur-xl"></div><img alt="Modern barbershop interior with professional setup" class="relative w-full h-96 lg:h-[600px] object-cover rounded-3xl shadow-2xl" src="https://images.unsplash.com/photo-1585747860715-2ba37e788b70?q=80&amp;w=1600&amp;auto=format&amp;fit=crop"></div></div></section>`);
}
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Home/Hero.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const Hero = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$4 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<header${ssrRenderAttrs(mergeProps({ class: "fixed top-0 w-full z-50 glass-effect border-b border-gray-800" }, _attrs))}><div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between"><a href="#" class="flex items-center gap-3 font-bold text-xl text-gray-100"><div class="w-10 h-10 bg-gradient-to-br from-primary-600 to-primary-700 rounded-lg flex items-center justify-center text-white text-lg">✂️</div> Skin Fade Barbershop </a><nav class="hidden md:flex items-center gap-8"><a href="#services" class="text-gray-300 hover:text-primary-400 transition-colors font-medium">Services &amp; Prices</a><a href="#team" class="text-gray-300 hover:text-primary-400 transition-colors font-medium">Our Team</a><a href="#testimonials" class="text-gray-300 hover:text-primary-400 transition-colors font-medium">Reviews</a><a href="#booking" class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-primary-600 to-primary-500 text-white font-semibold hover:shadow-xl hover:shadow-primary-500/25 transition-all">Book Now</a></nav><a href="#booking" class="md:hidden px-4 py-2 rounded-lg bg-primary-600 text-white font-medium">Book</a></div></header>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Home/Navbar.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const Navbar = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main$3 = {
  __name: "Services",
  __ssrInlineRender: true,
  props: {
    services: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({
        id: "services",
        class: "py-32 bg-gray-950"
      }, _attrs))}><div class="max-w-7xl mx-auto px-4"><div class="text-center mb-20"><h2 class="text-4xl lg:text-6xl font-bold text-gray-100 mb-6">Services &amp; Prices</h2><p class="text-xl text-gray-400 max-w-3xl mx-auto">Professional grooming services at competitive rates with premium quality guaranteed</p></div><div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 mb-16"><!--[-->`);
      ssrRenderList(__props.services, (service) => {
        _push(`<div class="service-card gradient-border"><div class="gradient-border-content p-8"><div class="flex items-start justify-between gap-4 mb-6"><div class="text-4xl">`);
        _push(ssrRenderComponent(unref(Icon), {
          icon: service.icon,
          width: "35",
          height: "35"
        }, null, _parent));
        _push(`</div><div class="text-right"><div class="text-3xl font-bold text-primary-400">$${ssrInterpolate(service.price)}</div><div class="text-sm text-gray-500">~${ssrInterpolate(service.duration_minutes)} minutes</div></div></div><h3 class="font-bold text-xl text-gray-100 mb-3">${ssrInterpolate(service.name)}</h3><p class="text-gray-400 leading-relaxed">${ssrInterpolate(service.description)}</p></div></div>`);
      });
      _push(`<!--]--></div><div class="text-center"><a href="#booking" class="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-primary-600 to-primary-500 text-white font-semibold hover:shadow-2xl hover:shadow-primary-500/25 transition-all"> Book Service Now <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"></path></svg></a></div></div></section>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Home/Services.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {
  __name: "Team",
  __ssrInlineRender: true,
  props: {
    employees: Array
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({
        id: "team",
        class: "py-32 bg-gray-900/30"
      }, _attrs))}><div class="max-w-7xl mx-auto px-4"><div class="text-center mb-20"><h2 class="text-4xl lg:text-6xl font-bold text-gray-100 mb-6">Meet Our Team</h2><p class="text-xl text-gray-400 max-w-3xl mx-auto">Choose your preferred barber during booking. Our master stylists bring years of expertise and passion to every cut.</p></div><div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-10"><!--[-->`);
      ssrRenderList(__props.employees, (employee) => {
        _push(`<div class="gradient-border hover:scale-105 transition-all duration-500 h-full"><div class="gradient-border-content p-8 h-full flex flex-col"><div class="flex items-center gap-6 mb-6"><img${ssrRenderAttr("src", employee.photo)}${ssrRenderAttr("alt", employee.name)} class="w-20 h-20 rounded-full object-cover border-2 border-primary-500/30"><div><h3 class="font-bold text-xl text-gray-100">${ssrInterpolate(employee.name)}</h3><div class="text-sm text-gray-300">${ssrInterpolate(employee.job_title)}</div><div class="text-sm text-primary-400">⭐ ${ssrInterpolate(employee.rating)}/5</div></div></div><p class="text-gray-400 leading-relaxed mb-4">${ssrInterpolate(employee.bio)}</p><div class="text-xs text-gray-500"><strong class="text-gray-400">Specializes in:</strong> ${ssrInterpolate(employee.job_title)}</div></div></div>`);
      });
      _push(`<!--]--></div></div></section>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Home/Team.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "Testimonials",
  __ssrInlineRender: true,
  props: {
    testimonials: Array
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({
        id: "testimonials",
        class: "py-32 bg-gray-950"
      }, _attrs))}><div class="max-w-7xl mx-auto px-4"><div class="text-center mb-20"><h2 class="text-4xl lg:text-6xl font-bold text-gray-100 mb-6">What Our Clients Say</h2><p class="text-xl text-gray-400 max-w-3xl mx-auto">Real feedback from satisfied customers who trust us with their style</p></div><div class="grid lg:grid-cols-3 gap-8"><!--[-->`);
      ssrRenderList(__props.testimonials, (testimonial) => {
        _push(`<div class="gradient-border hover:scale-105 transition-all duration-500 h-full"><div class="gradient-border-content p-8 h-full flex flex-col"><div class="mb-6"><div class="text-primary-400 text-xl mb-4"><!--[-->`);
        ssrRenderList(testimonial.rating, (star) => {
          _push(`<span>★</span>`);
        });
        _push(`<!--]--></div><p class="text-gray-300 text-lg leading-relaxed italic">&quot;${ssrInterpolate(testimonial.content)}&quot;</p></div><div class="border-t border-gray-700 pt-6 flex justify-between items-center"><div class="font-semibold text-gray-100">${ssrInterpolate(testimonial.name)}</div><div class="text-xs text-gray-400 bg-gray-800 px-3 py-1 rounded-full">${ssrInterpolate(testimonial.service.name)}</div></div></div></div>`);
      });
      _push(`<!--]--></div></div></section>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Home/Testimonials.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "Home",
  __ssrInlineRender: true,
  props: {
    employees: Array,
    services: Array,
    minDate: String,
    maxDate: String,
    testimonials: Array
  },
  setup(__props) {
    const page = usePage();
    onMounted(() => {
      document.querySelectorAll('a[href^="#"]').forEach((a) => {
        a.addEventListener("click", (e) => {
          const target = document.querySelector(a.getAttribute("href"));
          if (!target) return;
          e.preventDefault();
          const header = document.querySelector("header");
          const off = header ? header.offsetHeight : 0;
          const y = target.getBoundingClientRect().top + window.pageYOffset - off - 8;
          window.scrollTo({ top: y, behavior: "smooth" });
        });
      });
    });
    watch(page.props.flash, (flash) => {
      if (flash.success) {
        useToast().success(flash.success);
      } else if (flash.error) {
        useToast().error(flash.error);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Home" }, null, _parent));
      _push(ssrRenderComponent(Navbar, null, null, _parent));
      _push(ssrRenderComponent(Hero, null, null, _parent));
      _push(ssrRenderComponent(Feature, null, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, { services: __props.services }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, { employees: __props.employees }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, { testimonials: __props.testimonials }, null, _parent));
      _push(ssrRenderComponent(Booking, {
        employees: __props.employees,
        services: __props.services,
        minDate: __props.minDate,
        maxDate: __props.maxDate
      }, null, _parent));
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Home.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
