<script setup>
</script>
<template>
    <section class="py-32 bg-gray-900/50">
    <div class="max-w-7xl mx-auto px-4">
      <div class="text-center mb-20">
        <h2 class="text-4xl lg:text-6xl font-bold text-gray-100 mb-6">Why Choose Us?</h2>
        <p class="text-xl text-gray-400 max-w-3xl mx-auto leading-relaxed">
          Professional service, transparent pricing, and a booking experience designed for your convenience.
        </p>
      </div>
      <div class="grid lg:grid-cols-3 gap-10">
        <!-- Feature 1 -->
        <div class="relative group h-full">
          <div class="absolute inset-0 bg-gradient-to-r from-primary-600 to-primary-500 rounded-2xl opacity-0 group-hover:opacity-100 transition-all duration-500 blur-xl"></div>
          <div class="relative h-full p-10 bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl border border-gray-700 hover:border-primary-500/50 transition-all duration-500">
            <div class="w-16 h-16 bg-gray-700 rounded-2xl flex items-center justify-center text-gray-300 text-2xl mb-8 group-hover:bg-primary-500/20 group-hover:text-primary-400 transition-all duration-300">
              <svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
              </svg>
            </div>
            <h3 class="font-bold text-2xl text-gray-100 mb-4">Master Barbers</h3>
            <p class="text-gray-400 text-lg leading-relaxed">Skilled professionals with years of experience in modern fades, classic cuts, and precision styling with personal consultation.</p>
          </div>
        </div>
        <!-- Feature 2 -->
        <div class="relative group h-full">
          <div class="absolute inset-0 bg-gradient-to-r from-primary-600 to-primary-500 rounded-2xl opacity-0 group-hover:opacity-100 transition-all duration-500 blur-xl"></div>
          <div class="relative h-full p-10 bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl border border-gray-700 hover:border-primary-500/50 transition-all duration-500">
            <div class="w-16 h-16 bg-gray-700 rounded-2xl flex items-center justify-center text-gray-300 text-2xl mb-8 group-hover:bg-primary-500/20 group-hover:text-primary-400 transition-all duration-300">
              <svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                <path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"/>
              </svg>
            </div>
            <h3 class="font-bold text-2xl text-gray-100 mb-4">Transparent Pricing</h3>
            <p class="text-gray-400 text-lg leading-relaxed">Clear, upfront pricing with no hidden fees. Premium service packages and loyalty rewards for regular clients.</p>
          </div>
        </div>
        <!-- Feature 3 -->
        <div class="relative group h-full">
          <div class="absolute inset-0 bg-gradient-to-r from-primary-600 to-primary-500 rounded-2xl opacity-0 group-hover:opacity-100 transition-all duration-500 blur-xl"></div>
          <div class="relative h-full p-10 bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl border border-gray-700 hover:border-primary-500/50 transition-all duration-500">
            <div class="w-16 h-16 bg-gray-700 rounded-2xl flex items-center justify-center text-gray-300 text-2xl mb-8 group-hover:bg-primary-500/20 group-hover:text-primary-400 transition-all duration-300">
              <svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17 12h-5v5h5v-5zM16 1v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2h-1V1h-2zm3 18H5V8h14v11z"/>
              </svg>
            </div>
            <h3 class="font-bold text-2xl text-gray-100 mb-4">Smart Booking</h3>
            <p class="text-gray-400 text-lg leading-relaxed">Streamlined 4-step process: Choose service → Select barber → Pick time → Instant confirmation. Simple and efficient.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
