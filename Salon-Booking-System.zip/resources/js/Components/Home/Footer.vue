<script setup>
</script>

<template>
    <footer class="bg-gray-950 border-t border-gray-800">
    <div class="max-w-7xl mx-auto px-4 py-16">
      <div class="grid lg:grid-cols-4 gap-10">
        <div class="lg:col-span-2">
          <div class="flex items-center gap-3 font-bold text-xl mb-6">
            <div class="w-10 h-10 bg-gradient-to-br from-primary-600 to-primary-700 rounded-lg flex items-center justify-center text-lg">✂️</div>
            <span class="text-gray-100">Skin Fade Barbershop</span>
          </div>
          <p class="text-gray-400 leading-relaxed mb-6 max-w-md">Premium men's grooming services in the heart of the city. Professional cuts, expert styling, and exceptional service since 2020.</p>
          <div class="text-gray-300 space-y-2">
            <p class="flex items-center gap-2">📍 Downtown • 4th Circle</p>
            <p class="flex items-center gap-2">🕐 Daily 10 AM - 9 PM</p>
          </div>
        </div>
        <div>
          <div class="font-semibold text-lg mb-6 text-gray-100">Contact</div>
          <div class="space-y-3 text-gray-300">
            <p class="flex items-center gap-2">📱 +962 7X XXX XXXX</p>
            <p class="flex items-center gap-2">📧 info@skinfadebarbershop.com</p>
            <p class="flex items-center gap-2">📸 @skin.fade.barber</p>
          </div>
        </div>
        <div>
          <div class="font-semibold text-lg mb-6 text-gray-100">Quick Links</div>
          <ul class="space-y-3">
            <li><a href="#services" class="text-gray-300 hover:text-primary-400 transition-colors">Services</a></li>
            <li><a href="#team" class="text-gray-300 hover:text-primary-400 transition-colors">Our Team</a></li>
            <li><a href="#testimonials" class="text-gray-300 hover:text-primary-400 transition-colors">Reviews</a></li>
            <li><a href="#booking" class="text-gray-300 hover:text-primary-400 transition-colors">Book Now</a></li>
          </ul>
        </div>
      </div>
      <div class="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
        <p>&copy; 2024 Skin Fade Barbershop. All rights reserved.</p>
      </div>
    </div>
  </footer>
</template>
