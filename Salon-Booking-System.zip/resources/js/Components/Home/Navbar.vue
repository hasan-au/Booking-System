<script setup>
</script>
<template>
    <!-- Navbar -->
  <header class="fixed top-0 w-full z-50 glass-effect border-b border-gray-800">
    <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
      <a href="#" class="flex items-center gap-3 font-bold text-xl text-gray-100">
        <div class="w-10 h-10 bg-gradient-to-br from-primary-600 to-primary-700 rounded-lg flex items-center justify-center text-white text-lg">✂️</div>
        Skin Fade Barbershop
      </a>
      <nav class="hidden md:flex items-center gap-8">
        <a href="#services" class="text-gray-300 hover:text-primary-400 transition-colors font-medium">Services & Prices</a>
        <a href="#team" class="text-gray-300 hover:text-primary-400 transition-colors font-medium">Our Team</a>
        <a href="#testimonials" class="text-gray-300 hover:text-primary-400 transition-colors font-medium">Reviews</a>
        <a href="#booking" class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-primary-600 to-primary-500 text-white font-semibold hover:shadow-xl hover:shadow-primary-500/25 transition-all">Book Now</a>
      </nav>
      <a href="#booking" class="md:hidden px-4 py-2 rounded-lg bg-primary-600 text-white font-medium">Book</a>
    </div>
  </header>
</template>
